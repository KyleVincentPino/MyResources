package JobSeeking_DS_LE;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
// Remove the ambiguous List import and explicitly import java.util.List
import java.util.List;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;

public class JavaSwing extends JFrame {
    private HashMapClass hashMapClass;
    private JobSeekerManager jobSeekerManager;
    private EmployerManager employerManager;
    private Authentication authentication;
    private BST bst;
    private Recommendation recommendation;
    
    // UI Components
    private JTabbedPane tabbedPane;
    private JPanel jobSeekerPanel;
    private JPanel employerPanel;
    private JPanel jobPostPanel;
    private JPanel applicationPanel;
    
    public JavaSwing() {
        // Initialize all manager classes
        hashMapClass = new HashMapClass();
        java.util.List<JobPost> jobPosts = new ArrayList<>();  // Explicitly specify java.util.List
        jobSeekerManager = new JobSeekerManager(jobPosts);
        employerManager = new EmployerManager();
        authentication = new Authentication();
        bst = new BST();
        recommendation = new Recommendation(new ArrayList<>(), jobPosts, new ArrayList<>(), new ArrayList<>());
        
        // Setup the main frame
        setTitle("Job Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Initialize UI components
        initializeUI();
    }
    
    private void initializeUI() {
        // Create main tabbed pane
        tabbedPane = new JTabbedPane();
        
        // Initialize panels
        createJobSeekerPanel();
        createEmployerPanel();
        createJobPostPanel();
        createApplicationPanel();
        
        // Add panels to tabbed pane
        tabbedPane.addTab("Job Seekers", jobSeekerPanel);
        tabbedPane.addTab("Employers", employerPanel);
        tabbedPane.addTab("Job Posts", jobPostPanel);
        tabbedPane.addTab("Applications", applicationPanel);
        
        // Add tabbed pane to frame
        add(tabbedPane);
        
        // Add menu bar
        createMenuBar();
    }
    
    private void createJobSeekerPanel() {
        jobSeekerPanel = new JPanel(new BorderLayout());
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add form components
        formPanel.add(new JLabel("ID:"));
        JTextField idField = new JTextField();
        formPanel.add(idField);
        
        formPanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField();
        formPanel.add(nameField);
        
        formPanel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField();
        formPanel.add(emailField);
        
        formPanel.add(new JLabel("Phone:"));
        JTextField phoneField = new JTextField();
        formPanel.add(phoneField);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Add Job Seeker");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        
        // Add action listeners
        addButton.addActionListener(e -> {
            JobSeeker jobSeeker = new JobSeeker(
                idField.getText(),
                nameField.getText(),
                emailField.getText(),
                phoneField.getText(),
                new ArrayList<>(),
                0,
                "Medium",
                1
            );
            hashMapClass.addJobSeeker(jobSeeker);
            clearFields(idField, nameField, emailField, phoneField);
        });
        
        // Add panels to main panel
        jobSeekerPanel.add(formPanel, BorderLayout.NORTH);
        jobSeekerPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void createEmployerPanel() {
        employerPanel = new JPanel(new BorderLayout());
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add form components
        formPanel.add(new JLabel("ID:"));
        JTextField idField = new JTextField();
        formPanel.add(idField);
        
        formPanel.add(new JLabel("Company Name:"));
        JTextField companyField = new JTextField();
        formPanel.add(companyField);
        
        formPanel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField();
        formPanel.add(emailField);
        
        formPanel.add(new JLabel("Contact Number:"));
        JTextField phoneField = new JTextField();
        formPanel.add(phoneField);
        
        formPanel.add(new JLabel("Industry Type:"));
        JTextField industryField = new JTextField();
        formPanel.add(industryField);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Add Employer");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        
        // Add action listeners
        addButton.addActionListener(e -> {
            Employer employer = new Employer(
                idField.getText(),
                companyField.getText(),
                emailField.getText(),
                phoneField.getText(),
                industryField.getText()
            );
            hashMapClass.addEmployer(employer);
            clearFields(idField, companyField, emailField, phoneField, industryField);
        });
        
        // Add panels to main panel
        employerPanel.add(formPanel, BorderLayout.NORTH);
        employerPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void createJobPostPanel() {
        jobPostPanel = new JPanel(new BorderLayout());
        
        // Implementation similar to other panels but for job posts
        // Add necessary components and listeners
        JLabel placeholder = new JLabel("Job Posts Panel - To be implemented");
        placeholder.setHorizontalAlignment(JLabel.CENTER);
        jobPostPanel.add(placeholder);
    }
    
    private void createApplicationPanel() {
        applicationPanel = new JPanel(new BorderLayout());
        
        // Implementation similar to other panels but for applications
        // Add necessary components and listeners
        JLabel placeholder = new JLabel("Applications Panel - To be implemented");
        placeholder.setHorizontalAlignment(JLabel.CENTER);
        applicationPanel.add(placeholder);
    }
    
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem loadItem = new JMenuItem("Load");
        JMenuItem exitItem = new JMenuItem("Exit");
        
        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        
        // Add action listeners
        exitItem.addActionListener(e -> System.exit(0));
        
        // Help menu
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);
        
        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        
        setJMenuBar(menuBar);
    }
    
    private void clearFields(JTextField... fields) {
        for (JTextField field : fields) {
            field.setText("");
        }
    }
    
    public static void main(String[] args) {
        // Set Look and Feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Launch the application
        SwingUtilities.invokeLater(() -> {
            JavaSwing app = new JavaSwing();
            app.setVisible(true);
        });
    }
}