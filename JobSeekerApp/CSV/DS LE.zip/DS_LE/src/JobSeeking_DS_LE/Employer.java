package JobSeeking_DS_LE;

public class Employer implements Comparable<Employer> {

    private String id;                // Unique ID for the employer
    private String companyName;       // Name of the company
    private String email;             // Employer's email address
    private String contactNumber;     // Contact number
    private String industryType;      // Type of industry (e.g., "IT", "Manufacturing")

    // Constructor
    public Employer(String id, String companyName, String email, String contactNumber, String industryType) {
        this.id = id;
        this.companyName = companyName;
        this.email = email;
        this.contactNumber = contactNumber;
        this.industryType = industryType;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }
    
    @Override
    public int compareTo(Employer other) {
        return this.id.compareTo(other.id);  // Assuming comparing by id (you can adjust this logic)
    }

    @Override
    public String toString() {
        return "Employer{" +
                "id='" + id + '\'' +
                ", companyName='" + companyName + '\'' +
                ", email='" + email + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", industryType='" + industryType + '\'' +
                '}';
    }
}