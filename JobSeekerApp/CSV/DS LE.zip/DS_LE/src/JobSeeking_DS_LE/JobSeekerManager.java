package JobSeeking_DS_LE;

import java.util.ArrayList;
import java.util.List;

public class JobSeekerManager {
    private List<JobSeeker> jobSeekers;
    private List<JobApplication> jobApplications;
    private List<JobPost> jobPosts;

    public JobSeekerManager(List<JobPost> jobPosts) {
        this.jobSeekers = new ArrayList<>();
        this.jobApplications = new ArrayList<>();
        this.jobPosts = jobPosts;
    }

    // Add a new job seeker to the system
    public void addJobSeeker(JobSeeker jobSeeker) {
        jobSeekers.add(jobSeeker);
        System.out.println("Job Seeker added: " + jobSeeker);
    }

    // Remove a job seeker by ID
    public boolean removeJobSeeker(String id) {
        return jobSeekers.removeIf(seeker -> seeker.getId().equals(id));
    }

    // Update job seeker details
    public void updateJobSeeker(String id, JobSeeker updatedSeeker) {
        for (int i = 0; i < jobSeekers.size(); i++) {
            if (jobSeekers.get(i).getId().equals(id)) {
                jobSeekers.set(i, updatedSeeker);
                System.out.println("Job Seeker updated: " + updatedSeeker);
                return;
            }
        }
        System.out.println("Job Seeker not found.");
    }

    // Job seeker applies for a job post
    public void applyForJob(String jobSeekerId, String jobPostId, String resume, String coverLetter) {
        JobSeeker jobSeeker = null;
        for (JobSeeker seeker : jobSeekers) {
            if (seeker.getId().equals(jobSeekerId)) {
                jobSeeker = seeker;
                break;
            }
        }
        
        if (jobSeeker != null) {
            JobApplication application = new JobApplication(
                    String.valueOf(jobApplications.size() + 1), 
                    jobPostId, 
                    jobSeekerId, 
                    new java.util.Date(), 
                    resume, 
                    coverLetter, 
                    "Pending");
            jobApplications.add(application);
            System.out.println("Job application submitted: " + application);
        } else {
            System.out.println("Job Seeker not found.");
        }
    }

    // Get job applications for a specific job post
    public List<JobApplication> getApplicationsForJobPost(String jobPostId) {
        List<JobApplication> result = new ArrayList<>();
        for (JobApplication app : jobApplications) {
            if (app.getJobPostId().equals(jobPostId)) {
                result.add(app);
            }
        }
        return result;
    }

    // Get a list of all job seekers
    public List<JobSeeker> getJobSeekers() {
        return jobSeekers;
    }

    // Get a list of all job applications
    public List<JobApplication> getJobApplications() {
        return jobApplications;
    }
}