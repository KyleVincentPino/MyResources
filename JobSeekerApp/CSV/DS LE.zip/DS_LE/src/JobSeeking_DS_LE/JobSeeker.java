package JobSeeking_DS_LE;

import java.util.ArrayList;
import java.util.List;

public class JobSeeker implements Comparable<JobSeeker> {
    private String id;                // Unique ID for the job seeker
    private String name;              // Name of the job seeker
    private String email;             // Email address
    private String phoneNumber;       // Contact number
    private List<String> skills;      // List of skills
    private int experience;           // Number of years of experience
    private String financialNeed;     // Financial priority (e.g., "High", "Medium", "Low")
    private int urgency;              // 1 for low, 2 for medium, 3 for high urgency

    // Constructor
    public JobSeeker(String id, String name, String email, String phoneNumber, List<String> skills, int experience, String financialNeed, int urgency) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.skills = skills != null ? skills : new ArrayList<>();
        this.experience = experience;
        this.financialNeed = financialNeed;
        this.urgency = urgency;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters for skills
    public List<String> getSkills() {
        // Return an empty list if skills is null to avoid NullPointerException
        return skills != null ? skills : new ArrayList<>();
    }

    public void setSkills(List<String> skills) {
        // If the input skills list is null, initialize it as an empty list
        this.skills = skills != null ? skills : new ArrayList<>();
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public String getFinancialNeed() {
        return financialNeed;
    }

    public void setFinancialNeed(String financialNeed) {
        this.financialNeed = financialNeed;
    }

    public int getUrgency() {
        return urgency;
    }

    public void setUrgency(int urgency) {
        this.urgency = urgency;
    }

    // Calculate priority based on attributes like skills, experience, financial need, and urgency
    public int calculatePriority() {
        int priority = 0;

        // Calculate priority based on skills, experience, financial need, and urgency
        priority += (skills.size() * 5); // Example: 5 points for each skill
        priority += (experience * 10);  // Example: 10 points for each year of experience
        priority += ("High".equals(financialNeed) ? 20 : ("Medium".equals(financialNeed) ? 10 : 5));
        priority += (urgency * 30);  // Example: 30 points for each urgency level

        return priority;
    }

    // Compare JobSeekers based on priority
    @Override
    public int compareTo(JobSeeker other) {
        return Integer.compare(this.calculatePriority(), other.calculatePriority());
    }

    @Override
    public String toString() {
        return "JobSeeker{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", skills=" + skills +
                ", experience=" + experience +
                ", financialNeed='" + financialNeed + '\'' +
                ", urgency=" + urgency +
                '}';
    }
}

