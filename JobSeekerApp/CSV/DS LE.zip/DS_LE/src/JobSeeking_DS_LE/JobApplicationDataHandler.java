package JobSeeking_DS_LE;

import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class JobApplicationDataHandler {
    private static final String FILE_NAME = "jobapplications.csv";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    // Write JobApplication data to file
    public static void writeJobApplications(List<JobApplication> jobApplications) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (JobApplication ja : jobApplications) {
                writer.write(String.join(",",
                        ja.getId(),
                        ja.getJobPostId(),
                        ja.getJobSeekerId(),
                        DATE_FORMAT.format(ja.getApplicationDate()),
                        ja.getResume(),
                        ja.getCoverLetter(),
                        ja.getStatus()));
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Read JobApplication data from file
    public static List<JobApplication> readJobApplications() {
        List<JobApplication> jobApplications = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                jobApplications.add(new JobApplication(
                        data[0], data[1], data[2],
                        DATE_FORMAT.parse(data[3]),
                        data[4], data[5], data[6]));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return jobApplications;
    }
}