package JobSeeking_DS_LE;

import java.util.Date;

public class JobPost {
    private String id;                   // Unique Job Post ID
    private String title;                // Job title
    private String companyName;          // Company posting the job
    private String jobDescription;       // Description of the job
    private String requirements;         // Required skills/qualifications
    private Date postDate;               // Date when the job was posted
    private String location;             // Job location
    private String industryType;         // Type of industry (e.g., "IT", "Manufacturing")

    // Constructor
    public JobPost(String id, String title, String companyName, String jobDescription, 
                   String requirements, Date postDate, String location, String industryType) {
        this.id = id;
        this.title = title;
        this.companyName = companyName;
        this.jobDescription = jobDescription;
        this.requirements = requirements;
        this.postDate = postDate;
        this.location = location;
        this.industryType = industryType;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public Date getPostDate() {
        return postDate;
    }

    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }

    @Override
    public String toString() {
        return "JobPost{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", companyName='" + companyName + '\'' +
                ", jobDescription='" + jobDescription + '\'' +
                ", requirements='" + requirements + '\'' +
                ", postDate=" + postDate +
                ", location='" + location + '\'' +
                ", industryType='" + industryType + '\'' +
                '}';
    }
}