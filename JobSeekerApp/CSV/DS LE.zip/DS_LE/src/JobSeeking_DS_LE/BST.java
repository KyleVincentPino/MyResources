package JobSeeking_DS_LE;

public class BST {
    private BinaryTree<JobSeeker> jobSeekerTree;
    private BinaryTree<Employer> employerTree;

    public BST() {
        jobSeekerTree = new BinaryTree<>();
        employerTree = new BinaryTree<>();
    }

    // Insert JobSeeker into the tree
    public void insertJobSeeker(JobSeeker jobSeeker) {
        jobSeekerTree.insert(jobSeeker);
    }

    // Insert Employer into the tree
    public void insertEmployer(Employer employer) {
        employerTree.insert(employer);
    }

    // Search for JobSeeker by ID
    public JobSeeker findJobSeekerById(String id) {
        return jobSeekerTree.search(new JobSeeker(id, "", "", "", null, 0, "", 0));
    }

    // Search for Employer by ID
    public Employer findEmployerById(String id) {
        return employerTree.search(new Employer(id, "", "", "", ""));
    }

    // In-order traversal of JobSeekers
    public void displayJobSeekers() {
        jobSeekerTree.inorderTraversal();
    }

    // In-order traversal of Employers
    public void displayEmployers() {
        employerTree.inorderTraversal();
    }

    // Delete a JobSeeker from the tree
    public void deleteJobSeeker(JobSeeker jobSeeker) {
        jobSeekerTree.delete(jobSeeker);
    }

    // Delete an Employer from the tree
    public void deleteEmployer(Employer employer) {
        employerTree.delete(employer);
    }
}