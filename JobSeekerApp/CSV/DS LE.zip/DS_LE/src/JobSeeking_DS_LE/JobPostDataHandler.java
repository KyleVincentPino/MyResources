package JobSeeking_DS_LE;

import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class JobPostDataHandler {
    private static final String FILE_NAME = "jobposts.csv";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    // Write JobPost data to file
    public static void writeJobPosts(List<JobPost> jobPosts) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (JobPost jp : jobPosts) {
                writer.write(String.join(",",
                        jp.getId(),
                        jp.getTitle(),
                        jp.getCompanyName(),
                        jp.getJobDescription(),
                        jp.getRequirements(),
                        DATE_FORMAT.format(jp.getPostDate()),
                        jp.getLocation(),
                        jp.getIndustryType()));
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Read JobPost data from file
    public static List<JobPost> readJobPosts() {
        List<JobPost> jobPosts = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                jobPosts.add(new JobPost(
                        data[0], data[1], data[2], data[3],
                        data[4], DATE_FORMAT.parse(data[5]),
                        data[6], data[7]));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return jobPosts;
    }
}